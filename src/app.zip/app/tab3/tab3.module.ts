import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicSharedModule } from '../ionic.shared.module';

import { Tab3Page } from './tab3.page';

const routes: Routes = [
  {
    path: '',
    component: Tab3Page,
  },
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicSharedModule,
    RouterModule.forChild(routes),
  ],
  declarations: [Tab3Page],
})
export class Tab3PageModule {}
